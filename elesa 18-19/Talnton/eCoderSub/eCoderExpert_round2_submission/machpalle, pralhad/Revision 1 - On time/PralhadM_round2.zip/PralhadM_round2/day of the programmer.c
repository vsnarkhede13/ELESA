int main()
{
    int yy,dd;
    scanf("%d",&yy);
    if(yy>=1700 && yy<1918)
    {
        if(yy%4==0)
            dd=12;
        else
            dd=13;
    }
    if(yy>=1919 && yy<=2700)
    {
        if(yy%400==0 || (yy%4==0 && yy%100!=0))
            dd=12;
        else
        dd=13;
    }
    if( yy==1918)
    {
            dd=26;
    }
    
    printf("%d.09.%d",dd,yy);
    return 0;
}