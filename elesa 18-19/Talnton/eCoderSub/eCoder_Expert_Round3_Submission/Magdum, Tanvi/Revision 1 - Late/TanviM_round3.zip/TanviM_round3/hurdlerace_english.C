#include<stdio.h>
#include<conio.h>
void main()
{
	void hurdleRace(int,int,int*);
	int i,n,ht,*ptr;
	clrscr();
	printf("\nenter no. of hurdles:");
	scanf("%d",&n);
	printf("\nenter initial ht.:");
	scanf("%d",&ht);
	ptr=(int *)malloc(n*sizeof(int));
	printf("\nenter ht. of hurdles:\n");
	for(i=0;i<n;i++)
		scanf("%d",(ptr+i));
	hurdleRace(n,ht,ptr);
	getch();
}
void hurdleRace(int n, int ht, int *ptr)
{
	int i,max=0;
	for(i=0;i<n;i++)
	{
		if(*(ptr+i)>max)
			max=*(ptr+i);
	}
	ht=max-ht;
	if(ht<0)
		ht=0;
	printf("\nminimum reqd. doses of potion:%d",ht);
}