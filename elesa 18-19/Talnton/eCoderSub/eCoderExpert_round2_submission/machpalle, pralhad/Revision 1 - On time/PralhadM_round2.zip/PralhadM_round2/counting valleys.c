
int main()
{
    int n,v=0,i,l=0;
    scanf("%d",&n);
    char s[n];
    scanf("%s",s);
    for(i=0;i<n;i++)
    {
        if(s[i]=='U')
          ++l;
        if(s[i]=='D')
            --l;
        if(l==0 &&s[i]=='U')
            ++v;
    }
    printf("%d",v);        
   
    return 0;
}
