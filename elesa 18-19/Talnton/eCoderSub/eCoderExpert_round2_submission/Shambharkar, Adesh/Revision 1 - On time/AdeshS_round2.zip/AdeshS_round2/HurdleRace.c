#include<stdio.h>
int hurdlerace(int *p,int n,int k)
{
    int i=0,max=*p;
    p++;
    for(i=0;i<n;i++,p++)
    {
        if(*p>max)
            max=*p;
    }
    if(k>max)
        return 0;
    else
        return (max-k);
}
int main()
{
    int hurdlerace(int *,int,int);
    int n,k,i;
    int *a,*b;
    do
    {
        scanf("%d",&n);
    }while(!(n>=1));
    do
    {
        scanf("%d",&k);
    }while(!(k<=100));
    a=(int*)malloc(sizeof(int)*n);
    for(i=0,b=a;i<n;i++,a++)
    {
        scanf("%d",a);
        if(*a>1||*a<100)
            continue;
    }
    printf("%d",hurdlerace(b,n,k));
    return 0;
}
