
int main()
{
    int b,n,m,i,j,max=-1,sum;
    scanf("%d%d%d",&b,&n,&m);
    int k[n],u[m];
    for(i=0;i<n;i++)
        scanf("%d",&k[i]);
    for(j=0;j<m;j++)
        scanf("%d",&u[j]);
    for(i=0;i<n;i++)
    {
        for(j=0;j<m;j++)
        {
            sum=k[i]+u[j];
            if(sum<=b)
            {
                if(sum>max)
                    max=sum;
            }
        }
    }
        printf("%d",max);
    return 0;
}