#include<stdio.h>
#include<conio.h>
void main()
{
	int yr,var;
	printf("\nenter year:");
	scanf("%d",&yr);
	if(yr<1918)
	{
		if(yr%4==0)
			var=29;
		else
			var=28;
	}
	if(yr>1918)
	{
		if(yr%400==0 || (yr%4==0 && yr%100!=0))
			var=29;
		else
			var=28;
	}
	if(yr==1918)
		var=14;
	var=var+31+31+30+31+30+31+31;
	var=256-var;
	printf("date- %d.09.%d",var,yr);
	getch();
}