int main()
{
    int n,i,j,cst,s=1,k=0;
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++)
        scanf("%d",&a[i]);
    for(i=0;i<n;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(a[i]>a[j])
            {
                cst=a[i];
                a[i]=a[j];
                a[j]=cst;    
            }
        }
    }
    for(i=0;i<n;i++)
    {
        if(s>k)
            k=s;
        s=1;
        for(j=i+1;j<n;j++)
        {
            if(abs(a[i]-a[j])<=1)
                s++;
            else
                break;
        }
    }
    printf("%d",k);
    return 0;
    
}