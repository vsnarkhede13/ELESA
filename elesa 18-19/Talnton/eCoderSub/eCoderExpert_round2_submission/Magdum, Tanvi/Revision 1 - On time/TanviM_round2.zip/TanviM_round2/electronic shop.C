#include<stdio.h>
#include<conio.h>
void main()
{
	long int i,j,s,n,m,max=0,sum=0;
	long int *k,*u;
	clrscr();
	printf("\nenter amount:");
	scanf("%ld",&s);
	printf("\nenter no. of keyboards:");
	scanf("%ld",&n);
	printf("\nenter no. of usb drives:");
	scanf("%ld",&m);
	k=(long int *)malloc(n*sizeof(long int));
	u=(long int *)malloc(m*sizeof(long int));
	printf("\nenter prices of keyboards:\n");
	for(i=0;i<n;i++)
		scanf("%ld",(k+i));
	printf("\nenter prices of usb drives:\n");
	for(i=0;i<m;i++)
		scanf("%ld",(u+i));
	for(i=0;i<n;i++)
	{
		for(j=0;j<m;j++)
		{
			sum=*(k+i)+(*(u+j));
			if(sum>max && sum<=s)
				max=sum;
		}
	}
	if(max==0)
		printf("\n-1");
	else
		printf("\n%ld",max);
	getch();
}