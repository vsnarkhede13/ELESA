int main()
{
    int n,k,i,max;
    scanf("%d%d",&n,&k);
    int heights[n];
    for(i=0;i<n;i++)
        scanf("%d",&heights[i]);
    max=heights[0];
    for(i=0;i<n;i++)
    {
        if(heights[i]>max)
            max=heights[i];
    }
    if(k<max)
        printf("%d",(max-k));
    else
        printf("0");
    return 0;
}