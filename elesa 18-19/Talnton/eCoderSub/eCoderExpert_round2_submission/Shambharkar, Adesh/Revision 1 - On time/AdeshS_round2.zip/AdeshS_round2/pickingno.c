#include<stdio.h>
#include<stdlib.h>
int main()
{
    int n,cnt=1,b,i,j,diff=0;
    scanf("%d",&n);
    int a[n];
    for(i=0;i<n;i++)
        scanf("%d",&a[i]);
    for(i=0;i<n;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(a[i]>a[j])
            {
                b=a[i];
                a[i]=a[j];
                a[j]=b;
            }
        }
    }
    for(i=0,b=0;i<n;i++)
    {
        if(cnt>b)
            b=cnt;
        cnt=1;
        for(j=i+1;j<n;j++)
        {
            if(i==j)
                continue;
            diff=a[i]-a[j];
            if(abs(diff)<=1)
                cnt++;
        }
    }
    printf("%d",b);
    return 0;
}