#include<stdio.h>
#include<conio.h>
void main()
{
	int i,n,ht,max=0,*ptr;
	clrscr();
	printf("\nenter no. of hurdles:");
	scanf("%d",&n);
	printf("\nenter initial ht.:");
	scanf("%d",&ht);
	ptr=(int *)malloc(n*sizeof(int));
	printf("\nenter ht. of hurdles:\n");
	for(i=0;i<n;i++)
		scanf("%d",(ptr+i));
	for(i=0;i<n;i++)
	{
		if(*(ptr+i)>max)
			max=*(ptr+i);
	}
	ht=max-ht;
	printf("\nrequired doses of potion:%d",ht);
	getch();
}