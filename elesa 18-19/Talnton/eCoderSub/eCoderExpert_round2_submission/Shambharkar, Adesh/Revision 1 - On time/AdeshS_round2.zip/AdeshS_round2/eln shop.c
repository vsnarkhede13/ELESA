#include<stdio.h>
int main()
{
    long int n,m,i,j;
    long int bug=0,sum=0,psum=0;
    scanf("%ld",&bug);
    scanf("%ld",&n);
    scanf("%ld",&m);
    long int a[n],b[m];
    for(i=0;i<n;i++)
        scanf("%ld",&a[i]);
    for(i=0;i<m;i++)
        scanf("%ld",&b[i]);
    for(i=0;i<n;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(a[i]>a[j])
            {
                psum=a[i];
                a[i]=a[j];
                a[j]=psum;
            }
        }
    }
    for(i=0;i<n;i++)
    {
        for(j=i+1;j<n;j++)
        {
            if(b[i]>b[j])
            {
                psum=b[i];
                b[i]=b[j];
                b[j]=psum;
            }
        }
    }
    psum=0;

    for(i=0;i<n;i++)
    {
	for(j=0;j<m;j++)
	{
	    sum=a[i]+b[j];
        if(i==0&&j==0)
        {
            if(bug<sum)
            {
                printf("-1");
                return 0;
            }
        }
	    if(sum==bug)
        {
            printf("%ld",sum);
            return 0;
        }
	    if(sum<bug)
	    {
		if(sum>=psum)
		    psum=sum;
	    }
        
	}
    }
    printf("%ld",psum);
    return 0;
}