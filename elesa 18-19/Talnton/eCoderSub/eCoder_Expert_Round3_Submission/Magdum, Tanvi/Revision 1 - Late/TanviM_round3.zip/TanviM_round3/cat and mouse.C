#include<stdio.h>
#include<conio.h>
void main()
{
	void catAndMouse(int,int,int);
	int *ptr,n,i,j;
	clrscr();
	printf("\nenter no. of queries:");
	scanf("%d",&n);
	ptr=(int *)malloc(n*3*sizeof(int));
	printf("\nenter position:\n");
	for(i=0;i<n;i++){
		for(j=0;j<3;j++)
			scanf("%d",(ptr+i*n+j));
	}
	for(i=0;i<n;i++){
		catAndMouse(*(ptr+i*n+0),*(ptr+i*n+1),*(ptr+i*n+2));
	}
	getch();
}
void catAndMouse(int x,int y,int z)
{
	while(1)
	{
		if(x==z && y==z)
		{
			printf("\nmouse C");
			break;
		}
		else if(x==z)
		{
			printf("\ncat A");
			break;
		}
		else if(y==z)
		{
			printf("\ncat B");
			break;
		}
		if(x<z) x++;
		if(x>z) x--;
		if(y<z) y++;
		if(y>z) y--;
	}
}