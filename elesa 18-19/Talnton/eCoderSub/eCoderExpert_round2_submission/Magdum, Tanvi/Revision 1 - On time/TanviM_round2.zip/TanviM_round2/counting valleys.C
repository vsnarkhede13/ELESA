#include<stdio.h>
#include<conio.h>
void main()
{
	int n,i,flg=0,level=0,cnt=0;
	char *ptr;
	clrscr();
	printf("\nenter length of string:");
	scanf("%d",&n);
	n=n+1;
	ptr=(char *)malloc(n*sizeof(char));
	printf("\nenter string:\n");
	for(i=0;i<n;i++)
		scanf("%c",(ptr+i));
	for(i=0;i<n;i++)
	{
		if(*(ptr+i)=='D')
			level--;
		if(*(ptr+i)=='U')
			level++;
		if(level<0)
			flg=1;
		if(level>0)
			flg=0;
		if(flg==1 && level==0)
			cnt++;
	}

	printf("\nno. of valleys:%d",cnt);
	getch();
}