#include<stdio.h>
int main()
{
    char st[1000000];
    long int i=0,n,v=0,cnt=0;
    do
    {
        scanf("%ld",&n);
    }while(!(n>=2&&n<=1000000));
    for(i=0;i<n;i++)
    {
        do
        {
            scanf("%c",&st[i]);
        }while(!('U'==st[i]||'D'==st[i]));
    }
    for(i=0;i<n;i++)
    {
        if(st[i]=='D')
        {
            v++;
        }
        else
        {
            v--;
        }
        if(st[i-1]=='U'&&st[i]=='U'&&v==0)
            cnt++;
        if(v>0)
        {
            if(st[i]=='U'&&st[i-1]=='U'&&st[i+1]=='D'&&st[i+2]=='D')
                cnt++;
        }
        
    }
    printf("%ld",cnt);
    return 0;
}